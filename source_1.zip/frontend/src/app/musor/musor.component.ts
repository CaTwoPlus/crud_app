import { Component } from '@angular/core';

@Component({
  selector: 'app-musor',
  templateUrl: './musor.component.html',
  styleUrls: ['./musor.component.css']
})
export class MusorComponent {

}
