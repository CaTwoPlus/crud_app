// Üres szülő osztály, polimorfizmus megvalósításához
export class Model {
    constructor() {}
}